package com.bharath.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserproducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
